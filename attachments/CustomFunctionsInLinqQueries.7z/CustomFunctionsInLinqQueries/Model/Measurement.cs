﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomFunctionsInLinqQueries.Model
{
    public class Measurement
    {
        public int MeasurementId { get; set; }

        public double Value { get; set; }

        public DateTime MeasuredAt { get; set; }

        public int DeviceId { get; set; }
    }
}
