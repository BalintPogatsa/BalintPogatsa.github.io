﻿using CodeFirstStoreFunctions;
using CustomFunctionsInLinqQueries.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomFunctionsInLinqQueries
{
    public class PlantContext : DbContext
    {
        public PlantContext()
            : base("PlantContext")
        {
        }
        
        public DbSet<Device> Devices { get; set; }
        public DbSet<Measurement> Measurements { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("SANDBOX");

            modelBuilder.Entity<Device>().HasKey(d => d.DeviceId);

            modelBuilder.Entity<Measurement>().HasKey(m => m.MeasurementId);
            modelBuilder.Entity<Measurement>().Property(m => m.MeasuredAt).HasColumnType("DATE");

            modelBuilder.Conventions.Add(new FunctionsConvention<PlantContext>("SANDBOX"));
            modelBuilder.Conventions.Add(new FunctionsConvention("SANDBOX", typeof(Functions)));
        }

        //[DbFunction("CodeFirstDatabaseSchema", "to_date_local")]
        //public static DateTime ToDate(string dateTimeToConvert, string convertFormat)
        //{
        //    // no need to provide an implementation
        //    throw new NotSupportedException();
        //}
    }

    public class Functions
    {
        //Add this function to your DB

        //create or replace FUNCTION TO_DATE_LOCAL 
        //(
        //  DATETIMETOCONVERT IN VARCHAR2 
        //, CONVERTFORMAT IN VARCHAR2 
        //) RETURN DATE AS 
        //BEGIN
        //  RETURN to_date(DATETIMETOCONVERT, CONVERTFORMAT);
        //END TO_DATE_LOCAL;
        [DbFunction("CodeFirstDatabaseSchema", "TO_DATE_LOCAL")]
        [DbFunctionDetails()]
        public static DateTime ToDateLocal(string dateTimeToConvert, string convertFormat)
        {
            // no need to provide an implementation
            throw new NotSupportedException();
        }

        [DbFunction("CodeFirstDatabaseSchema", "TO_DATE")]
        [DbFunctionDetails(IsBuiltIn=BuiltInOptions.BuiltIn)]
        public static DateTime ToDate(string dateTimeToConvert, string convertFormat)
        {
            // no need to provide an implementation
            throw new NotSupportedException();
        }
    }
}
