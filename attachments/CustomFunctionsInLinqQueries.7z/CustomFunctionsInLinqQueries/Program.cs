﻿using CustomFunctionsInLinqQueries.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomFunctionsInLinqQueries
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new PlantContext())
            {
                //context.Devices.Add(new Device() { DeviceId = 1, DeviceName = "SAWReader1" });

                //for (int i = 1; i <= 31; i++)
                //    context.Measurements.Add(new Measurement() { DeviceId = 1, MeasuredAt = new DateTime(2016, 1, i, 10, 0, 0), MeasurementId = i, Value = i });
                
                //context.SaveChanges();

                var measurement = context.Measurements.Where(m => m.MeasuredAt == new DateTime(2016, 1, 1, 10, 0, 0)).FirstOrDefault();
                Console.WriteLine(measurement.MeasurementId);

                measurement = context.Measurements.Where(m => m.MeasuredAt == Functions.ToDateLocal("2016.01.01 10:00:00", "YYYY.MM.DD Hh24:MI:SS")).FirstOrDefault();
                Console.WriteLine(measurement.MeasurementId);

                measurement = context.Measurements.Where(m => m.MeasuredAt == Functions.ToDate("2016.01.01 10:00:00", "YYYY.MM.DD Hh24:MI:SS")).FirstOrDefault();
                Console.WriteLine(measurement.MeasurementId);

            }
        }
    }
}
